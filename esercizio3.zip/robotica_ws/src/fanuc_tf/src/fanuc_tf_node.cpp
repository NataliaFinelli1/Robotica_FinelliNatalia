#include <ros/ros.h>
#include <tf2_ros/transform_listener.h>
#include <geometry_msgs/TransformStamped.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Vector3.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <stdio.h>
#define _USE_MATH_DEFINES
#include <cmath>

struct EulerAngles {
    float roll, pitch, yaw;
};

EulerAngles ToEulerAngles(float x, float y, float z, float  w) {
    EulerAngles angles;

    // roll (x-axis rotation)
    float sinr_cosp = 2 * (w * x + y * z);
    float cosr_cosp = 1 - 2 * (x * x + y * y);
    angles.roll = std::atan2(sinr_cosp, cosr_cosp);

    // pitch (y-axis rotation)
    float sinp = 2 * (w * y - z * x);
    if (std::abs(sinp) >= 1)
        angles.pitch = std::copysign(M_PI / 2, sinp); // use 90 degrees if out of range
    else
        angles.pitch = std::asin(sinp);

    // yaw (z-axis rotation)
    float siny_cosp = 2 * (w * z + x * y);
    float cosy_cosp = 1 - 2 * (y * y + z * z);
    angles.yaw = std::atan2(siny_cosp, cosy_cosp);

    return angles;
}

int main(int argc, char** argv) {

    if(argc < 3){
        ROS_ERROR("Not enough parameters");
        return 1;
    }

    std::string target = argv[1];
    std::string source = argv[2];
    ros::init(argc, argv, "fanuc_tf2_listener");
    ros::NodeHandle nodeHandle;
    tf2_ros::Buffer tfBuffer;
    tf2_ros::TransformListener tfListener(tfBuffer);
    ros::Rate rate(1.0);

    while (nodeHandle.ok()) {
        geometry_msgs::TransformStamped ts;
 
        try {
            ts = tfBuffer.lookupTransform(argv[1],argv[2], ros::Time(0));
        } catch (tf2::TransformException &exception) {
            ROS_WARN("%s", exception.what());
            ros::Duration(1.0).sleep();
            continue;
        }

        
        tf2::Quaternion q = tf2::Quaternion(ts.transform.rotation.x,ts.transform.rotation.y, ts.transform.rotation.z, ts.transform.rotation.w);
        tf2::Vector3 translation = tf2::Vector3(ts.transform.translation.x,ts.transform.translation.y,ts.transform.translation.z);
        tf2::Vector3 axis = q.getAxis();
        tf2::Matrix3x3 m = tf2::Matrix3x3(q);
        EulerAngles eulerAngles = ToEulerAngles(ts.transform.rotation.x,ts.transform.rotation.y, ts.transform.rotation.z, ts.transform.rotation.w);

        ROS_INFO("\n\n*********Transformation from %s to %s*********\n\n"
        "----------Translation----------\n"
        "x: %g\n"
        "y: %g\n"
        "z: %g\n\n"
        "----------Axis/angle----------\n"
        "Axis = [%g %g %g]\n"
        "Angle = %g\n\n"
        "----------Rotation matrix----------\n"
        "[%g %g %g]\n"
        "[%g %g %g]\n"
        "[%g %g %g]\n\n"
        "------- Euler angle (RPY) -------\n"
        "[%g %g %g]\n\n",
        source.c_str(), target.c_str(), translation.getX(), translation.getY(), translation.getZ(),
        axis.getX(), axis.getY(), axis.getZ(), 
        q.getAngle(),
        m[0][0],m[0][1],m[0][2],m[1][0],m[1][1],m[1][2],m[2][0],m[2][1],m[2][2],
        eulerAngles.roll, eulerAngles.pitch, eulerAngles.yaw);

        
        rate.sleep();

    }
    return 0;
};