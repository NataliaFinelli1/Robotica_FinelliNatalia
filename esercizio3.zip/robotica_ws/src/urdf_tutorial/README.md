# urdf_tutorial
See the tutorials over at http://wiki.ros.org/urdf_tutorial
