// Auto-generated. Do not edit!

// (in-package joint_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let joint_msg = require('./joint_msg.js');

//-----------------------------------------------------------

class joint_array {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.joint_array = null;
    }
    else {
      if (initObj.hasOwnProperty('joint_array')) {
        this.joint_array = initObj.joint_array
      }
      else {
        this.joint_array = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type joint_array
    // Serialize message field [joint_array]
    // Serialize the length for message field [joint_array]
    bufferOffset = _serializer.uint32(obj.joint_array.length, buffer, bufferOffset);
    obj.joint_array.forEach((val) => {
      bufferOffset = joint_msg.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type joint_array
    let len;
    let data = new joint_array(null);
    // Deserialize message field [joint_array]
    // Deserialize array length for message field [joint_array]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.joint_array = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.joint_array[i] = joint_msg.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.joint_array.forEach((val) => {
      length += joint_msg.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'joint_msgs/joint_array';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e115ae5ee5f854379bd8689a854d2cfe';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    joint_msg[] joint_array 
    
    ================================================================================
    MSG: joint_msgs/joint_msg
    string label
    float32 angle
    float32 elongation 
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new joint_array(null);
    if (msg.joint_array !== undefined) {
      resolved.joint_array = new Array(msg.joint_array.length);
      for (let i = 0; i < resolved.joint_array.length; ++i) {
        resolved.joint_array[i] = joint_msg.Resolve(msg.joint_array[i]);
      }
    }
    else {
      resolved.joint_array = []
    }

    return resolved;
    }
};

module.exports = joint_array;
